Please see summary below for explanation of files in this zip:

EDA.py                  | Exploratory Data Analysis and Cleansing of extracted Odoo data (does not include raw business data)
ForecastDashboard.xlsx  | Dashboard with aggregated values across extracted odoo data (multiple sheets) 
OdooQueryNOCRED.py      | Code to query Odoo DB directly and extract the relevant fields needed for the report (omitted credentials and authenticating data)
OdooRESTAPI.txt         | Copy/Paste of Odoo REST api used to integrate spreadsheet with Odoo ERP system (developed by Odoo consultant)
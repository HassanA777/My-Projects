import xmlrpc.client
import ssl
import pandas as pd
import re as regex
import csv

url = 'https://captivea-usa-greyscaleai.odoo.com'
db = 'captivea-usa-greyscaleai-main-3705608'
username = "hassan@greyscaleai.com"
password = ""
#common = xmlrpc.client.ServerProxy('{}/xmlrpc/2/common'.format(url))
common = xmlrpc.client.ServerProxy('{}/xmlrpc/2/common'.format(url), allow_none=True,verbose=False, use_datetime=True,context=ssl._create_unverified_context())
print(common.version())
key = ""
uid = common.authenticate(db, username, password, {})
models = xmlrpc.client.ServerProxy('{}/xmlrpc/2/object'.format(url), allow_none=True,verbose=False, use_datetime=True,context=ssl._create_unverified_context())
#models = xmlrpc.client.ServerProxy('{}/xmlrpc/2/object'.format(url), allow_none=True,verbose=False, use_datetime=True,context=ssl._create_unverified_context())

undesiredCharacters = ['[',']','"','{','}']

inventory = models.execute_kw(db, uid, password,
    'stock.quant', 'search_read',
    [[['id', '>', 0],['location_id.usage','=','internal']]],
    {'fields': ['product_id', 'location_id', 'lot_id','x_studio_vendor', 'x_studio_gsai_part','x_studio_vendor_part',
                'x_studio_manufacturer', 'available_quantity','quantity','product_uom_id', 'inventory_quantity',
                'reserved_quantity', 'value']})

purchaseOrders = models.execute_kw(db, uid, password,
    'purchase.order.line', 'search_read',
    [[['id', '>', 0]]],
    {'fields': ['id', 'order_id', 'product_id', 'name','x_studio_vendor_part', 'x_studio_vendor_product',
                'x_studio_manufacturer_1', 'product_qty','qty_received','date_planned', 'date_order','state']})

components = models.execute_kw(db, uid, password,
    'stock.move', 'search_read',
    [[['id', '>', 0]]],
    {'fields': ['id', 'x_studio_linked_mrp', 'x_studio_linked_mrp_priority','x_studio_linked_mrp_machine_name',
                'x_studio_linked_mrp_mo_type', 'x_studio_linked_mrp_product_version', 'x_studio_linked_mrp_scheduled_date',
                'x_studio_linked_mrp_customer_commit', 'x_studio_linked_mrp_product', 'x_studio_linked_mrp_product_uom',
                'x_studio_linked_mrp_cm_po', 'x_studio_linked_mrp_base_status', 'x_studio_linked_mrp_add_on_status',
                'x_studio_linked_mrp_source', 'x_studio_linked_mrp_state', 'x_studio_linked_mrp_bom_display_name',
                'reference', 'product_id', 'x_studio_vendor_part',    'name', 'date', 'x_studio_manufacturer',
                'should_consume_qty', 'reserved_availability', 'quantity_done', 'product_qty', 'state']})

inventoryDF = pd.DataFrame(inventory)
purchaseDF = pd.DataFrame(purchaseOrders)
componentsDF = pd.DataFrame(components)
DFList = [inventoryDF,purchaseDF,componentsDF]
i = 0
for DF in DFList:
    DF.to_csv(f"{i}.csv")
    i+=1

test = componentsDF.loc[0]

